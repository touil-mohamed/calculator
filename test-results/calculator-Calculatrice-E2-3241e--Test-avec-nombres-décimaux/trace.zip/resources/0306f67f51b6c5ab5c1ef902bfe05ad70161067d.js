import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Calculator.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e7b5a740"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e7b5a740"; const useState = __vite__cjsImport3_react["useState"];
import {
  Button,
  Grid,
  Paper,
  Container,
  Typography,
  Box
} from "/node_modules/.vite/deps/@mui_material.js?v=e7b5a740";
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=e7b5a740";
import { Calculator } from "/src/logic/calculatorLogic.js";
const CalcButton = styled(Button)(({ theme }) => ({
  padding: theme.spacing(2),
  fontSize: "1.5rem",
  borderRadius: "8px",
  width: "100%",
  minHeight: "64px"
}));
_c = CalcButton;
const Display = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  textAlign: "right",
  fontSize: "2rem",
  marginBottom: theme.spacing(2),
  minHeight: "64px",
  background: "#f5f5f5",
  wordBreak: "break-all"
}));
_c2 = Display;
const CalculatorComponent = () => {
  _s();
  const [display, setDisplay] = useState("0");
  const [firstNumber, setFirstNumber] = useState(null);
  const [operator, setOperator] = useState(null);
  const [calculator] = useState(new Calculator());
  const [waitingForSecondNumber, setWaitingForSecondNumber] = useState(false);
  const buttons = [
    ["7", "8", "9", "+"],
    ["4", "5", "6", "-"],
    ["1", "2", "3", "*"],
    ["C", "0", "=", "/"]
  ];
  const handleNumber = (num) => {
    if (waitingForSecondNumber) {
      setDisplay(num);
      setWaitingForSecondNumber(false);
    } else {
      setDisplay(display === "0" ? num : display + num);
    }
  };
  const handleOperator = (op) => {
    setFirstNumber(parseFloat(display));
    setOperator(op);
    setWaitingForSecondNumber(true);
  };
  const handleEquals = () => {
    if (firstNumber === null || operator === null)
      return;
    try {
      const result = calculator.calculate(
        firstNumber,
        operator,
        parseFloat(display)
      );
      setDisplay(result.toString());
      setFirstNumber(null);
      setOperator(null);
    } catch (error) {
      setDisplay("Error");
    }
  };
  const handleClear = () => {
    setDisplay("0");
    setFirstNumber(null);
    setOperator(null);
    setWaitingForSecondNumber(false);
  };
  const handleButtonClick = (value) => {
    switch (value) {
      case "=":
        handleEquals();
        break;
      case "C":
        handleClear();
        break;
      case "+":
      case "-":
      case "*":
      case "/":
        handleOperator(value);
        break;
      default:
        handleNumber(value);
    }
  };
  return /* @__PURE__ */ jsxDEV(Container, { maxWidth: "sm", children: /* @__PURE__ */ jsxDEV(Box, { sx: { mt: 4 }, children: [
    /* @__PURE__ */ jsxDEV(
      Display,
      {
        elevation: 3,
        "data-testid": "display",
        children: display
      },
      void 0,
      false,
      {
        fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
        lineNumber: 106,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Grid, { container: true, spacing: 1, children: buttons.map(
      (row, rowIndex) => /* @__PURE__ */ jsxDEV(Grid, { container: true, item: true, spacing: 1, children: row.map(
        (button) => /* @__PURE__ */ jsxDEV(Grid, { item: true, xs: 3, children: /* @__PURE__ */ jsxDEV(
          CalcButton,
          {
            variant: "contained",
            color: button === "=" ? "primary" : button === "C" ? "error" : ["+", "-", "*", "/"].includes(button) ? "secondary" : "info",
            onClick: () => handleButtonClick(button),
            "data-testid": `button-${button}`,
            children: button
          },
          void 0,
          false,
          {
            fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
            lineNumber: 115,
            columnNumber: 19
          },
          this
        ) }, button, false, {
          fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
          lineNumber: 114,
          columnNumber: 13
        }, this)
      ) }, rowIndex, false, {
        fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
        lineNumber: 112,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
      lineNumber: 110,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: { mt: 4 }, children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", children: "Historique" }, void 0, false, {
        fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
        lineNumber: 136,
        columnNumber: 11
      }, this),
      calculator.getHistory().map(
        (item, index) => /* @__PURE__ */ jsxDEV(
          Paper,
          {
            sx: {
              p: 2,
              my: 1,
              display: "flex",
              justifyContent: "space-between"
            },
            children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                item.expression,
                " = ",
                item.result
              ] }, void 0, true, {
                fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
                lineNumber: 147,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: item.timestamp.toLocaleTimeString() }, void 0, false, {
                fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
                lineNumber: 148,
                columnNumber: 15
              }, this)
            ]
          },
          index,
          true,
          {
            fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
            lineNumber: 138,
            columnNumber: 11
          },
          this
        )
      ),
      calculator.getHistory().length > 0 && /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outlined",
          color: "error",
          onClick: () => calculator.clearHistory(),
          sx: { mt: 2 },
          "data-testid": "clear-history",
          children: "Effacer l'historique"
        },
        void 0,
        false,
        {
          fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
          lineNumber: 152,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
      lineNumber: 135,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
    lineNumber: 105,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
    lineNumber: 104,
    columnNumber: 5
  }, this);
};
_s(CalculatorComponent, "iaZz5/4YuM50x6yPB8kb7qKVV4U=");
_c3 = CalculatorComponent;
export default CalculatorComponent;
var _c, _c2, _c3;
$RefreshReg$(_c, "CalcButton");
$RefreshReg$(_c2, "Display");
$RefreshReg$(_c3, "CalculatorComponent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUdROzJCQXpHUjtBQUFpQixNQUFRLGNBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEM7QUFBQSxFQUNFQTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsYUFBYUYsT0FBT04sTUFBTSxFQUFFLENBQUMsRUFBRVMsTUFBTSxPQUFPO0FBQUEsRUFDaERDLFNBQVNELE1BQU1FLFFBQVEsQ0FBQztBQUFBLEVBQ3hCQyxVQUFVO0FBQUEsRUFDVkMsY0FBYztBQUFBLEVBQ2RDLE9BQU87QUFBQSxFQUNQQyxXQUFXO0FBQ2IsRUFBRTtBQUFFQyxLQU5FUjtBQVFOLE1BQU1TLFVBQVVYLE9BQU9KLEtBQUssRUFBRSxDQUFDLEVBQUVPLE1BQU0sT0FBTztBQUFBLEVBQzVDQyxTQUFTRCxNQUFNRSxRQUFRLENBQUM7QUFBQSxFQUN4Qk8sV0FBVztBQUFBLEVBQ1hOLFVBQVU7QUFBQSxFQUNWTyxjQUFjVixNQUFNRSxRQUFRLENBQUM7QUFBQSxFQUM3QkksV0FBVztBQUFBLEVBQ1hLLFlBQVk7QUFBQSxFQUNaQyxXQUFXO0FBQ2IsRUFBRTtBQUFFQyxNQVJFTDtBQVVOLE1BQU1NLHNCQUFzQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJQyxTQUFTLEdBQUc7QUFDMUMsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlGLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUNHLFVBQVVDLFdBQVcsSUFBSUosU0FBUyxJQUFJO0FBQzdDLFFBQU0sQ0FBQ0ssVUFBVSxJQUFJTCxTQUFTLElBQUlwQixXQUFXLENBQUM7QUFDOUMsUUFBTSxDQUFDMEIsd0JBQXdCQyx5QkFBeUIsSUFBSVAsU0FBUyxLQUFLO0FBRTFFLFFBQU1RLFVBQVU7QUFBQSxJQUNkLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRztBQUFBLElBQ25CLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRztBQUFBLElBQ25CLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRztBQUFBLElBQ25CLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRztBQUFBLEVBQUM7QUFHdEIsUUFBTUMsZUFBZUEsQ0FBQ0MsUUFBUTtBQUM1QixRQUFJSix3QkFBd0I7QUFDMUJQLGlCQUFXVyxHQUFHO0FBQ2RILGdDQUEwQixLQUFLO0FBQUEsSUFDakMsT0FBTztBQUNMUixpQkFBV0QsWUFBWSxNQUFNWSxNQUFNWixVQUFVWSxHQUFHO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBRUEsUUFBTUMsaUJBQWlCQSxDQUFDQyxPQUFPO0FBQzdCVixtQkFBZVcsV0FBV2YsT0FBTyxDQUFDO0FBQ2xDTSxnQkFBWVEsRUFBRTtBQUNkTCw4QkFBMEIsSUFBSTtBQUFBLEVBQ2hDO0FBRUEsUUFBTU8sZUFBZUEsTUFBTTtBQUN6QixRQUFJYixnQkFBZ0IsUUFBUUUsYUFBYTtBQUFNO0FBRS9DLFFBQUk7QUFDRixZQUFNWSxTQUFTVixXQUFXVztBQUFBQSxRQUN4QmY7QUFBQUEsUUFDQUU7QUFBQUEsUUFDQVUsV0FBV2YsT0FBTztBQUFBLE1BQ3BCO0FBQ0FDLGlCQUFXZ0IsT0FBT0UsU0FBUyxDQUFDO0FBQzVCZixxQkFBZSxJQUFJO0FBQ25CRSxrQkFBWSxJQUFJO0FBQUEsSUFDbEIsU0FBU2MsT0FBTztBQUNkbkIsaUJBQVcsT0FBTztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU1vQixjQUFjQSxNQUFNO0FBQ3hCcEIsZUFBVyxHQUFHO0FBQ2RHLG1CQUFlLElBQUk7QUFDbkJFLGdCQUFZLElBQUk7QUFDaEJHLDhCQUEwQixLQUFLO0FBQUEsRUFDakM7QUFFQSxRQUFNYSxvQkFBb0JBLENBQUNDLFVBQVU7QUFDbkMsWUFBUUEsT0FBSztBQUFBLE1BQ1gsS0FBSztBQUNIUCxxQkFBYTtBQUNiO0FBQUEsTUFDRixLQUFLO0FBQ0hLLG9CQUFZO0FBQ1o7QUFBQSxNQUNGLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFDSFIsdUJBQWVVLEtBQUs7QUFDcEI7QUFBQSxNQUNGO0FBQ0VaLHFCQUFhWSxLQUFLO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxhQUFVLFVBQVMsTUFDbEIsaUNBQUMsT0FBSSxJQUFJLEVBQUVDLElBQUksRUFBRSxHQUNmO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUFRLFdBQVc7QUFBQSxRQUNsQixlQUFZO0FBQUEsUUFDWHhCO0FBQUFBO0FBQUFBLE1BRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR0E7QUFBQSxJQUNBLHVCQUFDLFFBQUssV0FBUyxNQUFDLFNBQVMsR0FDdEJVLGtCQUFRZTtBQUFBQSxNQUFJLENBQUNDLEtBQUtDLGFBQ2pCLHVCQUFDLFFBQUssV0FBUyxNQUFDLE1BQUksTUFBQyxTQUFTLEdBQzNCRCxjQUFJRDtBQUFBQSxRQUFJLENBQUNHLFdBQ1IsdUJBQUMsUUFBSyxNQUFJLE1BQUMsSUFBSSxHQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixPQUNFQSxXQUFXLE1BQU0sWUFDakJBLFdBQVcsTUFBTSxVQUNqQixDQUFDLEtBQUssS0FBSyxLQUFLLEdBQUcsRUFBRUMsU0FBU0QsTUFBTSxJQUFJLGNBQ3hDO0FBQUEsWUFFRixTQUFTLE1BQU1OLGtCQUFrQk0sTUFBTTtBQUFBLFlBQ3ZDLGVBQWEsVUFBVUEsTUFBTTtBQUFBLFlBRTVCQTtBQUFBQTtBQUFBQSxVQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlBLEtBYnFCQSxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxNQUNELEtBakJtQ0QsVUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLElBQ0QsS0FyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBR0EsdUJBQUMsT0FBSSxJQUFJLEVBQUVILElBQUksRUFBRSxHQUNmO0FBQUEsNkJBQUMsY0FBVyxTQUFRLE1BQUssMEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQSxNQUNsQ2pCLFdBQVd1QixXQUFXLEVBQUVMO0FBQUFBLFFBQUksQ0FBQ00sTUFBTUMsVUFDbEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLElBQUk7QUFBQSxjQUNGQyxHQUFHO0FBQUEsY0FDSEMsSUFBSTtBQUFBLGNBQ0psQyxTQUFTO0FBQUEsY0FDVG1DLGdCQUFnQjtBQUFBLFlBQ2xCO0FBQUEsWUFFQTtBQUFBLHFDQUFDLFVBQU1KO0FBQUFBLHFCQUFLSztBQUFBQSxnQkFBVztBQUFBLGdCQUFJTCxLQUFLZDtBQUFBQSxtQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUN2Qyx1QkFBQyxVQUFNYyxlQUFLTSxVQUFVQyxtQkFBbUIsS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQTtBQUFBO0FBQUEsVUFUdENOO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdBO0FBQUEsTUFDRDtBQUFBLE1BQ0F6QixXQUFXdUIsV0FBVyxFQUFFUyxTQUFTLEtBQ2hDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixPQUFNO0FBQUEsVUFDTixTQUFTLE1BQU1oQyxXQUFXaUMsYUFBYTtBQUFBLFVBQ3ZDLElBQUksRUFBRWhCLElBQUksRUFBRTtBQUFBLFVBQ1osZUFBWTtBQUFBLFVBQWU7QUFBQTtBQUFBLFFBTDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0F6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLE9BekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwREEsS0EzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTREQTtBQUVKO0FBQUV6QixHQXZJSUQscUJBQW1CO0FBQUEyQyxNQUFuQjNDO0FBeUlOLGVBQWVBO0FBQW9CLElBQUFQLElBQUFNLEtBQUE0QztBQUFBQyxhQUFBbkQsSUFBQTtBQUFBbUQsYUFBQTdDLEtBQUE7QUFBQTZDLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJCdXR0b24iLCJHcmlkIiwiUGFwZXIiLCJDb250YWluZXIiLCJUeXBvZ3JhcGh5IiwiQm94Iiwic3R5bGVkIiwiQ2FsY3VsYXRvciIsIkNhbGNCdXR0b24iLCJ0aGVtZSIsInBhZGRpbmciLCJzcGFjaW5nIiwiZm9udFNpemUiLCJib3JkZXJSYWRpdXMiLCJ3aWR0aCIsIm1pbkhlaWdodCIsIl9jIiwiRGlzcGxheSIsInRleHRBbGlnbiIsIm1hcmdpbkJvdHRvbSIsImJhY2tncm91bmQiLCJ3b3JkQnJlYWsiLCJfYzIiLCJDYWxjdWxhdG9yQ29tcG9uZW50IiwiX3MiLCJkaXNwbGF5Iiwic2V0RGlzcGxheSIsInVzZVN0YXRlIiwiZmlyc3ROdW1iZXIiLCJzZXRGaXJzdE51bWJlciIsIm9wZXJhdG9yIiwic2V0T3BlcmF0b3IiLCJjYWxjdWxhdG9yIiwid2FpdGluZ0ZvclNlY29uZE51bWJlciIsInNldFdhaXRpbmdGb3JTZWNvbmROdW1iZXIiLCJidXR0b25zIiwiaGFuZGxlTnVtYmVyIiwibnVtIiwiaGFuZGxlT3BlcmF0b3IiLCJvcCIsInBhcnNlRmxvYXQiLCJoYW5kbGVFcXVhbHMiLCJyZXN1bHQiLCJjYWxjdWxhdGUiLCJ0b1N0cmluZyIsImVycm9yIiwiaGFuZGxlQ2xlYXIiLCJoYW5kbGVCdXR0b25DbGljayIsInZhbHVlIiwibXQiLCJtYXAiLCJyb3ciLCJyb3dJbmRleCIsImJ1dHRvbiIsImluY2x1ZGVzIiwiZ2V0SGlzdG9yeSIsIml0ZW0iLCJpbmRleCIsInAiLCJteSIsImp1c3RpZnlDb250ZW50IiwiZXhwcmVzc2lvbiIsInRpbWVzdGFtcCIsInRvTG9jYWxlVGltZVN0cmluZyIsImxlbmd0aCIsImNsZWFySGlzdG9yeSIsIl9jMyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNhbGN1bGF0b3IuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIEJ1dHRvbiwgXG4gIEdyaWQsIFxuICBQYXBlciwgXG4gIENvbnRhaW5lciwgXG4gIFR5cG9ncmFwaHksXG4gIEJveFxufSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwvc3R5bGVzJztcbmltcG9ydCB7IENhbGN1bGF0b3IgfSBmcm9tICcuLi9sb2dpYy9jYWxjdWxhdG9yTG9naWMnO1xuXG5jb25zdCBDYWxjQnV0dG9uID0gc3R5bGVkKEJ1dHRvbikoKHsgdGhlbWUgfSkgPT4gKHtcbiAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcbiAgZm9udFNpemU6ICcxLjVyZW0nLFxuICBib3JkZXJSYWRpdXM6ICc4cHgnLFxuICB3aWR0aDogJzEwMCUnLFxuICBtaW5IZWlnaHQ6ICc2NHB4Jyxcbn0pKTtcblxuY29uc3QgRGlzcGxheSA9IHN0eWxlZChQYXBlcikoKHsgdGhlbWUgfSkgPT4gKHtcbiAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcbiAgdGV4dEFsaWduOiAncmlnaHQnLFxuICBmb250U2l6ZTogJzJyZW0nLFxuICBtYXJnaW5Cb3R0b206IHRoZW1lLnNwYWNpbmcoMiksXG4gIG1pbkhlaWdodDogJzY0cHgnLFxuICBiYWNrZ3JvdW5kOiAnI2Y1ZjVmNScsXG4gIHdvcmRCcmVhazogJ2JyZWFrLWFsbCdcbn0pKTtcblxuY29uc3QgQ2FsY3VsYXRvckNvbXBvbmVudCA9ICgpID0+IHtcbiAgY29uc3QgW2Rpc3BsYXksIHNldERpc3BsYXldID0gdXNlU3RhdGUoJzAnKTtcbiAgY29uc3QgW2ZpcnN0TnVtYmVyLCBzZXRGaXJzdE51bWJlcl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW29wZXJhdG9yLCBzZXRPcGVyYXRvcl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2NhbGN1bGF0b3JdID0gdXNlU3RhdGUobmV3IENhbGN1bGF0b3IoKSk7XG4gIGNvbnN0IFt3YWl0aW5nRm9yU2Vjb25kTnVtYmVyLCBzZXRXYWl0aW5nRm9yU2Vjb25kTnVtYmVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBidXR0b25zID0gW1xuICAgIFsnNycsICc4JywgJzknLCAnKyddLFxuICAgIFsnNCcsICc1JywgJzYnLCAnLSddLFxuICAgIFsnMScsICcyJywgJzMnLCAnKiddLFxuICAgIFsnQycsICcwJywgJz0nLCAnLyddXG4gIF07XG5cbiAgY29uc3QgaGFuZGxlTnVtYmVyID0gKG51bSkgPT4ge1xuICAgIGlmICh3YWl0aW5nRm9yU2Vjb25kTnVtYmVyKSB7XG4gICAgICBzZXREaXNwbGF5KG51bSk7XG4gICAgICBzZXRXYWl0aW5nRm9yU2Vjb25kTnVtYmVyKGZhbHNlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0RGlzcGxheShkaXNwbGF5ID09PSAnMCcgPyBudW0gOiBkaXNwbGF5ICsgbnVtKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlT3BlcmF0b3IgPSAob3ApID0+IHtcbiAgICBzZXRGaXJzdE51bWJlcihwYXJzZUZsb2F0KGRpc3BsYXkpKTtcbiAgICBzZXRPcGVyYXRvcihvcCk7XG4gICAgc2V0V2FpdGluZ0ZvclNlY29uZE51bWJlcih0cnVlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVFcXVhbHMgPSAoKSA9PiB7XG4gICAgaWYgKGZpcnN0TnVtYmVyID09PSBudWxsIHx8IG9wZXJhdG9yID09PSBudWxsKSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gY2FsY3VsYXRvci5jYWxjdWxhdGUoXG4gICAgICAgIGZpcnN0TnVtYmVyLFxuICAgICAgICBvcGVyYXRvcixcbiAgICAgICAgcGFyc2VGbG9hdChkaXNwbGF5KVxuICAgICAgKTtcbiAgICAgIHNldERpc3BsYXkocmVzdWx0LnRvU3RyaW5nKCkpO1xuICAgICAgc2V0Rmlyc3ROdW1iZXIobnVsbCk7XG4gICAgICBzZXRPcGVyYXRvcihudWxsKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgc2V0RGlzcGxheSgnRXJyb3InKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xlYXIgPSAoKSA9PiB7XG4gICAgc2V0RGlzcGxheSgnMCcpO1xuICAgIHNldEZpcnN0TnVtYmVyKG51bGwpO1xuICAgIHNldE9wZXJhdG9yKG51bGwpO1xuICAgIHNldFdhaXRpbmdGb3JTZWNvbmROdW1iZXIoZmFsc2UpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUJ1dHRvbkNsaWNrID0gKHZhbHVlKSA9PiB7XG4gICAgc3dpdGNoICh2YWx1ZSkge1xuICAgICAgY2FzZSAnPSc6XG4gICAgICAgIGhhbmRsZUVxdWFscygpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ0MnOlxuICAgICAgICBoYW5kbGVDbGVhcigpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJysnOlxuICAgICAgY2FzZSAnLSc6XG4gICAgICBjYXNlICcqJzpcbiAgICAgIGNhc2UgJy8nOlxuICAgICAgICBoYW5kbGVPcGVyYXRvcih2YWx1ZSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaGFuZGxlTnVtYmVyKHZhbHVlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwic21cIj5cbiAgICAgIDxCb3ggc3g9e3sgbXQ6IDQgfX0+XG4gICAgICAgIDxEaXNwbGF5IGVsZXZhdGlvbj17M31cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cImRpc3BsYXlcIj5cbiAgICAgICAgICB7ZGlzcGxheX1cbiAgICAgICAgPC9EaXNwbGF5PlxuICAgICAgICA8R3JpZCBjb250YWluZXIgc3BhY2luZz17MX0+XG4gICAgICAgICAge2J1dHRvbnMubWFwKChyb3csIHJvd0luZGV4KSA9PiAoXG4gICAgICAgICAgICA8R3JpZCBjb250YWluZXIgaXRlbSBzcGFjaW5nPXsxfSBrZXk9e3Jvd0luZGV4fT5cbiAgICAgICAgICAgICAge3Jvdy5tYXAoKGJ1dHRvbikgPT4gKFxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezN9IGtleT17YnV0dG9ufT5cbiAgICAgICAgICAgICAgICAgIDxDYWxjQnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxuICAgICAgICAgICAgICAgICAgICBjb2xvcj17XG4gICAgICAgICAgICAgICAgICAgICAgYnV0dG9uID09PSAnPScgPyAncHJpbWFyeScgOlxuICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbiA9PT0gJ0MnID8gJ2Vycm9yJyA6XG4gICAgICAgICAgICAgICAgICAgICAgWycrJywgJy0nLCAnKicsICcvJ10uaW5jbHVkZXMoYnV0dG9uKSA/ICdzZWNvbmRhcnknIDpcbiAgICAgICAgICAgICAgICAgICAgICAnaW5mbydcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVCdXR0b25DbGljayhidXR0b24pfVxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD17YGJ1dHRvbi0ke2J1dHRvbn1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7YnV0dG9ufVxuICAgICAgICAgICAgICAgICAgPC9DYWxjQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvR3JpZD5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L0dyaWQ+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvR3JpZD5cbiAgICAgICAgXG4gICAgICAgIHsvKiBIaXN0b3JpcXVlICovfVxuICAgICAgICA8Qm94IHN4PXt7IG10OiA0IH19PlxuICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNlwiPkhpc3RvcmlxdWU8L1R5cG9ncmFwaHk+XG4gICAgICAgICAge2NhbGN1bGF0b3IuZ2V0SGlzdG9yeSgpLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgIDxQYXBlciBcbiAgICAgICAgICAgICAga2V5PXtpbmRleH0gXG4gICAgICAgICAgICAgIHN4PXt7IFxuICAgICAgICAgICAgICAgIHA6IDIsIFxuICAgICAgICAgICAgICAgIG15OiAxLCBcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsIFxuICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicgXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuPntpdGVtLmV4cHJlc3Npb259ID0ge2l0ZW0ucmVzdWx0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0udGltZXN0YW1wLnRvTG9jYWxlVGltZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvUGFwZXI+XG4gICAgICAgICAgKSl9XG4gICAgICAgICAge2NhbGN1bGF0b3IuZ2V0SGlzdG9yeSgpLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvbiBcbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCIgXG4gICAgICAgICAgICAgIGNvbG9yPVwiZXJyb3JcIiBcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY2FsY3VsYXRvci5jbGVhckhpc3RvcnkoKX1cbiAgICAgICAgICAgICAgc3g9e3sgbXQ6IDIgfX1cbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJjbGVhci1oaXN0b3J5XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgRWZmYWNlciBsJmFwb3M7aGlzdG9yaXF1ZVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0JveD5cbiAgICA8L0NvbnRhaW5lcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IENhbGN1bGF0b3JDb21wb25lbnQ7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9tb2hhbWVkL0RvY3VtZW50cy9DYWxjdWxhdG9yL3NyYy9jb21wb25lbnRzL0NhbGN1bGF0b3IuanN4In0=