import {
  CssBaseline_default
} from "/node_modules/.vite/deps/chunk-EJ2ESRIR.js?v=e7b5a740";
import "/node_modules/.vite/deps/chunk-7WOAOTKW.js?v=e7b5a740";
import "/node_modules/.vite/deps/chunk-JSQF3CKF.js?v=e7b5a740";
import "/node_modules/.vite/deps/chunk-JSZTVBPD.js?v=e7b5a740";
export {
  CssBaseline_default as default
};
//# sourceMappingURL=@mui_material_CssBaseline.js.map
