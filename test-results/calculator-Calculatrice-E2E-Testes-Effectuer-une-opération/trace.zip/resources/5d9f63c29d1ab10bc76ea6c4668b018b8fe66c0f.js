import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Calculator.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e7b5a740"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e7b5a740"; const useState = __vite__cjsImport3_react["useState"];
import {
  Button,
  Grid,
  Paper,
  Container,
  Typography,
  Box
} from "/node_modules/.vite/deps/@mui_material.js?v=e7b5a740";
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=e7b5a740";
import { Calculator } from "/src/logic/calculatorLogic.js";
const CalcButton = styled(Button)(({ theme }) => ({
  padding: theme.spacing(2),
  fontSize: "1.5rem",
  borderRadius: "8px",
  width: "100%",
  minHeight: "64px"
}));
_c = CalcButton;
const Display = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  textAlign: "right",
  fontSize: "2rem",
  marginBottom: theme.spacing(2),
  minHeight: "64px",
  background: "#f5f5f5",
  wordBreak: "break-all"
}));
_c2 = Display;
const CalculatorComponent = () => {
  _s();
  const [display, setDisplay] = useState("0");
  const [firstNumber, setFirstNumber] = useState(null);
  const [operator, setOperator] = useState(null);
  const [calculator] = useState(new Calculator());
  const [waitingForSecondNumber, setWaitingForSecondNumber] = useState(false);
  const [history, setHistory] = useState([]);
  const buttons = [
    ["7", "8", "9", "+"],
    ["4", "5", "6", "-"],
    ["1", "2", "3", "*"],
    ["C", "0", "=", "/"]
  ];
  const handleNumber = (num) => {
    if (waitingForSecondNumber) {
      setDisplay(num);
      setWaitingForSecondNumber(false);
    } else {
      setDisplay(display === "0" ? num : display + num);
    }
  };
  const handleOperator = (op) => {
    setFirstNumber(parseFloat(display));
    setOperator(op);
    setWaitingForSecondNumber(true);
  };
  const handleEquals = () => {
    if (firstNumber === null || operator === null)
      return;
    try {
      const result = calculator.calculate(
        firstNumber,
        operator,
        parseFloat(display)
      );
      setDisplay(result.toString());
      setFirstNumber(null);
      setOperator(null);
    } catch (error) {
      setDisplay("Error");
    }
  };
  const handleClear = () => {
    setDisplay("0");
    setFirstNumber(null);
    setOperator(null);
    setWaitingForSecondNumber(false);
  };
  const handleClearHistory = () => {
    calculator.clearHistory();
    setHistory([]);
  };
  const handleButtonClick = (value) => {
    switch (value) {
      case "=":
        handleEquals();
        break;
      case "C":
        handleClear();
        break;
      case "+":
      case "-":
      case "*":
      case "/":
        handleOperator(value);
        break;
      default:
        handleNumber(value);
    }
  };
  return /* @__PURE__ */ jsxDEV(Container, { maxWidth: "sm", children: /* @__PURE__ */ jsxDEV(Box, { sx: { mt: 4 }, children: [
    /* @__PURE__ */ jsxDEV(
      Display,
      {
        elevation: 3,
        "data-testid": "display",
        children: display
      },
      void 0,
      false,
      {
        fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
        lineNumber: 113,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Grid, { container: true, spacing: 1, children: buttons.map(
      (row, rowIndex) => /* @__PURE__ */ jsxDEV(Grid, { container: true, item: true, spacing: 1, children: row.map(
        (button) => /* @__PURE__ */ jsxDEV(Grid, { item: true, xs: 3, children: /* @__PURE__ */ jsxDEV(
          CalcButton,
          {
            variant: "contained",
            color: button === "=" ? "primary" : button === "C" ? "error" : ["+", "-", "*", "/"].includes(button) ? "secondary" : "info",
            onClick: () => handleButtonClick(button),
            "data-testid": `button-${button}`,
            children: button
          },
          void 0,
          false,
          {
            fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
            lineNumber: 122,
            columnNumber: 19
          },
          this
        ) }, button, false, {
          fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
          lineNumber: 121,
          columnNumber: 13
        }, this)
      ) }, rowIndex, false, {
        fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
        lineNumber: 119,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
      lineNumber: 117,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: { mt: 4 }, children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", children: "Historique" }, void 0, false, {
        fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
        lineNumber: 143,
        columnNumber: 11
      }, this),
      calculator.getHistory().map(
        (item, index) => /* @__PURE__ */ jsxDEV(
          Paper,
          {
            sx: {
              p: 2,
              my: 1,
              display: "flex",
              justifyContent: "space-between"
            },
            children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                item.expression,
                " = ",
                item.result
              ] }, void 0, true, {
                fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
                lineNumber: 154,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: item.timestamp.toLocaleTimeString() }, void 0, false, {
                fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
                lineNumber: 155,
                columnNumber: 15
              }, this)
            ]
          },
          index,
          true,
          {
            fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
            lineNumber: 145,
            columnNumber: 11
          },
          this
        )
      ),
      calculator.getHistory().length > 0 && /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outlined",
          color: "error",
          onClick: handleClearHistory,
          sx: { mt: 2 },
          "data-testid": "clear-history",
          children: "Effacer l'historique"
        },
        void 0,
        false,
        {
          fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
          lineNumber: 159,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
      lineNumber: 142,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
    lineNumber: 112,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx",
    lineNumber: 111,
    columnNumber: 5
  }, this);
};
_s(CalculatorComponent, "w+M3jSiOeoSW1o+WUWrPXG8R3EA=");
_c3 = CalculatorComponent;
export default CalculatorComponent;
var _c, _c2, _c3;
$RefreshReg$(_c, "CalcButton");
$RefreshReg$(_c2, "Display");
$RefreshReg$(_c3, "CalculatorComponent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/mohamed/Documents/Calculator/src/components/Calculator.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0hROzJCQWhIUjtBQUFpQixNQUFRLGNBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEM7QUFBQSxFQUNFQTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsYUFBYUYsT0FBT04sTUFBTSxFQUFFLENBQUMsRUFBRVMsTUFBTSxPQUFPO0FBQUEsRUFDaERDLFNBQVNELE1BQU1FLFFBQVEsQ0FBQztBQUFBLEVBQ3hCQyxVQUFVO0FBQUEsRUFDVkMsY0FBYztBQUFBLEVBQ2RDLE9BQU87QUFBQSxFQUNQQyxXQUFXO0FBQ2IsRUFBRTtBQUFFQyxLQU5FUjtBQVFOLE1BQU1TLFVBQVVYLE9BQU9KLEtBQUssRUFBRSxDQUFDLEVBQUVPLE1BQU0sT0FBTztBQUFBLEVBQzVDQyxTQUFTRCxNQUFNRSxRQUFRLENBQUM7QUFBQSxFQUN4Qk8sV0FBVztBQUFBLEVBQ1hOLFVBQVU7QUFBQSxFQUNWTyxjQUFjVixNQUFNRSxRQUFRLENBQUM7QUFBQSxFQUM3QkksV0FBVztBQUFBLEVBQ1hLLFlBQVk7QUFBQSxFQUNaQyxXQUFXO0FBQ2IsRUFBRTtBQUFFQyxNQVJFTDtBQVVOLE1BQU1NLHNCQUFzQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJQyxTQUFTLEdBQUc7QUFDMUMsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlGLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUNHLFVBQVVDLFdBQVcsSUFBSUosU0FBUyxJQUFJO0FBQzdDLFFBQU0sQ0FBQ0ssVUFBVSxJQUFJTCxTQUFTLElBQUlwQixXQUFXLENBQUM7QUFDOUMsUUFBTSxDQUFDMEIsd0JBQXdCQyx5QkFBeUIsSUFBSVAsU0FBUyxLQUFLO0FBQzFFLFFBQU0sQ0FBQ1EsU0FBU0MsVUFBVSxJQUFJVCxTQUFTLEVBQUU7QUFHekMsUUFBTVUsVUFBVTtBQUFBLElBQ2QsQ0FBQyxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQUEsSUFDbkIsQ0FBQyxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQUEsSUFDbkIsQ0FBQyxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQUEsSUFDbkIsQ0FBQyxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQUEsRUFBQztBQUd0QixRQUFNQyxlQUFlQSxDQUFDQyxRQUFRO0FBQzVCLFFBQUlOLHdCQUF3QjtBQUMxQlAsaUJBQVdhLEdBQUc7QUFDZEwsZ0NBQTBCLEtBQUs7QUFBQSxJQUNqQyxPQUFPO0FBQ0xSLGlCQUFXRCxZQUFZLE1BQU1jLE1BQU1kLFVBQVVjLEdBQUc7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxpQkFBaUJBLENBQUNDLE9BQU87QUFDN0JaLG1CQUFlYSxXQUFXakIsT0FBTyxDQUFDO0FBQ2xDTSxnQkFBWVUsRUFBRTtBQUNkUCw4QkFBMEIsSUFBSTtBQUFBLEVBQ2hDO0FBRUEsUUFBTVMsZUFBZUEsTUFBTTtBQUN6QixRQUFJZixnQkFBZ0IsUUFBUUUsYUFBYTtBQUFNO0FBRS9DLFFBQUk7QUFDRixZQUFNYyxTQUFTWixXQUFXYTtBQUFBQSxRQUN4QmpCO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FZLFdBQVdqQixPQUFPO0FBQUEsTUFDcEI7QUFDQUMsaUJBQVdrQixPQUFPRSxTQUFTLENBQUM7QUFDNUJqQixxQkFBZSxJQUFJO0FBQ25CRSxrQkFBWSxJQUFJO0FBQUEsSUFDbEIsU0FBU2dCLE9BQU87QUFDZHJCLGlCQUFXLE9BQU87QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0IsY0FBY0EsTUFBTTtBQUN4QnRCLGVBQVcsR0FBRztBQUNkRyxtQkFBZSxJQUFJO0FBQ25CRSxnQkFBWSxJQUFJO0FBQ2hCRyw4QkFBMEIsS0FBSztBQUFBLEVBQ2pDO0FBRUEsUUFBTWUscUJBQXFCQSxNQUFNO0FBQy9CakIsZUFBV2tCLGFBQWE7QUFDeEJkLGVBQVcsRUFBRTtBQUFBLEVBQ2Y7QUFFQSxRQUFNZSxvQkFBb0JBLENBQUNDLFVBQVU7QUFDbkMsWUFBUUEsT0FBSztBQUFBLE1BQ1gsS0FBSztBQUNIVCxxQkFBYTtBQUNiO0FBQUEsTUFDRixLQUFLO0FBQ0hLLG9CQUFZO0FBQ1o7QUFBQSxNQUNGLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFDSFIsdUJBQWVZLEtBQUs7QUFDcEI7QUFBQSxNQUNGO0FBQ0VkLHFCQUFhYyxLQUFLO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxhQUFVLFVBQVMsTUFDbEIsaUNBQUMsT0FBSSxJQUFJLEVBQUVDLElBQUksRUFBRSxHQUNmO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUFRLFdBQVc7QUFBQSxRQUNsQixlQUFZO0FBQUEsUUFDWDVCO0FBQUFBO0FBQUFBLE1BRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR0E7QUFBQSxJQUNBLHVCQUFDLFFBQUssV0FBUyxNQUFDLFNBQVMsR0FDdEJZLGtCQUFRaUI7QUFBQUEsTUFBSSxDQUFDQyxLQUFLQyxhQUNqQix1QkFBQyxRQUFLLFdBQVMsTUFBQyxNQUFJLE1BQUMsU0FBUyxHQUMzQkQsY0FBSUQ7QUFBQUEsUUFBSSxDQUFDRyxXQUNSLHVCQUFDLFFBQUssTUFBSSxNQUFDLElBQUksR0FDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsT0FDRUEsV0FBVyxNQUFNLFlBQ2pCQSxXQUFXLE1BQU0sVUFDakIsQ0FBQyxLQUFLLEtBQUssS0FBSyxHQUFHLEVBQUVDLFNBQVNELE1BQU0sSUFBSSxjQUN4QztBQUFBLFlBRUYsU0FBUyxNQUFNTixrQkFBa0JNLE1BQU07QUFBQSxZQUN2QyxlQUFhLFVBQVVBLE1BQU07QUFBQSxZQUU1QkE7QUFBQUE7QUFBQUEsVUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQSxLQWJxQkEsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsTUFDRCxLQWpCbUNELFVBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxJQUNELEtBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxJQUdBLHVCQUFDLE9BQUksSUFBSSxFQUFFSCxJQUFJLEVBQUUsR0FDZjtBQUFBLDZCQUFDLGNBQVcsU0FBUSxNQUFLLDBCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DO0FBQUEsTUFDbENyQixXQUFXMkIsV0FBVyxFQUFFTDtBQUFBQSxRQUFJLENBQUNNLE1BQU1DLFVBQ2xDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxJQUFJO0FBQUEsY0FDRkMsR0FBRztBQUFBLGNBQ0hDLElBQUk7QUFBQSxjQUNKdEMsU0FBUztBQUFBLGNBQ1R1QyxnQkFBZ0I7QUFBQSxZQUNsQjtBQUFBLFlBRUE7QUFBQSxxQ0FBQyxVQUFNSjtBQUFBQSxxQkFBS0s7QUFBQUEsZ0JBQVc7QUFBQSxnQkFBSUwsS0FBS2hCO0FBQUFBLG1CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQ3ZDLHVCQUFDLFVBQU1nQixlQUFLTSxVQUFVQyxtQkFBbUIsS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQTtBQUFBO0FBQUEsVUFUdENOO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdBO0FBQUEsTUFDRDtBQUFBLE1BQ0E3QixXQUFXMkIsV0FBVyxFQUFFUyxTQUFTLEtBQ2hDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixPQUFNO0FBQUEsVUFDTixTQUFTbkI7QUFBQUEsVUFDVCxJQUFJLEVBQUVJLElBQUksRUFBRTtBQUFBLFVBQ1osZUFBWTtBQUFBLFVBQWU7QUFBQTtBQUFBLFFBTDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0F6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLE9BekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwREEsS0EzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTREQTtBQUVKO0FBQUU3QixHQTlJSUQscUJBQW1CO0FBQUE4QyxNQUFuQjlDO0FBZ0pOLGVBQWVBO0FBQW9CLElBQUFQLElBQUFNLEtBQUErQztBQUFBQyxhQUFBdEQsSUFBQTtBQUFBc0QsYUFBQWhELEtBQUE7QUFBQWdELGFBQUFELEtBQUEiLCJuYW1lcyI6WyJCdXR0b24iLCJHcmlkIiwiUGFwZXIiLCJDb250YWluZXIiLCJUeXBvZ3JhcGh5IiwiQm94Iiwic3R5bGVkIiwiQ2FsY3VsYXRvciIsIkNhbGNCdXR0b24iLCJ0aGVtZSIsInBhZGRpbmciLCJzcGFjaW5nIiwiZm9udFNpemUiLCJib3JkZXJSYWRpdXMiLCJ3aWR0aCIsIm1pbkhlaWdodCIsIl9jIiwiRGlzcGxheSIsInRleHRBbGlnbiIsIm1hcmdpbkJvdHRvbSIsImJhY2tncm91bmQiLCJ3b3JkQnJlYWsiLCJfYzIiLCJDYWxjdWxhdG9yQ29tcG9uZW50IiwiX3MiLCJkaXNwbGF5Iiwic2V0RGlzcGxheSIsInVzZVN0YXRlIiwiZmlyc3ROdW1iZXIiLCJzZXRGaXJzdE51bWJlciIsIm9wZXJhdG9yIiwic2V0T3BlcmF0b3IiLCJjYWxjdWxhdG9yIiwid2FpdGluZ0ZvclNlY29uZE51bWJlciIsInNldFdhaXRpbmdGb3JTZWNvbmROdW1iZXIiLCJoaXN0b3J5Iiwic2V0SGlzdG9yeSIsImJ1dHRvbnMiLCJoYW5kbGVOdW1iZXIiLCJudW0iLCJoYW5kbGVPcGVyYXRvciIsIm9wIiwicGFyc2VGbG9hdCIsImhhbmRsZUVxdWFscyIsInJlc3VsdCIsImNhbGN1bGF0ZSIsInRvU3RyaW5nIiwiZXJyb3IiLCJoYW5kbGVDbGVhciIsImhhbmRsZUNsZWFySGlzdG9yeSIsImNsZWFySGlzdG9yeSIsImhhbmRsZUJ1dHRvbkNsaWNrIiwidmFsdWUiLCJtdCIsIm1hcCIsInJvdyIsInJvd0luZGV4IiwiYnV0dG9uIiwiaW5jbHVkZXMiLCJnZXRIaXN0b3J5IiwiaXRlbSIsImluZGV4IiwicCIsIm15IiwianVzdGlmeUNvbnRlbnQiLCJleHByZXNzaW9uIiwidGltZXN0YW1wIiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwibGVuZ3RoIiwiX2MzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2FsY3VsYXRvci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgQnV0dG9uLCBcbiAgR3JpZCwgXG4gIFBhcGVyLCBcbiAgQ29udGFpbmVyLCBcbiAgVHlwb2dyYXBoeSxcbiAgQm94XG59IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSAnQG11aS9tYXRlcmlhbC9zdHlsZXMnO1xuaW1wb3J0IHsgQ2FsY3VsYXRvciB9IGZyb20gJy4uL2xvZ2ljL2NhbGN1bGF0b3JMb2dpYyc7XG5cbmNvbnN0IENhbGNCdXR0b24gPSBzdHlsZWQoQnV0dG9uKSgoeyB0aGVtZSB9KSA9PiAoe1xuICBwYWRkaW5nOiB0aGVtZS5zcGFjaW5nKDIpLFxuICBmb250U2l6ZTogJzEuNXJlbScsXG4gIGJvcmRlclJhZGl1czogJzhweCcsXG4gIHdpZHRoOiAnMTAwJScsXG4gIG1pbkhlaWdodDogJzY0cHgnLFxufSkpO1xuXG5jb25zdCBEaXNwbGF5ID0gc3R5bGVkKFBhcGVyKSgoeyB0aGVtZSB9KSA9PiAoe1xuICBwYWRkaW5nOiB0aGVtZS5zcGFjaW5nKDIpLFxuICB0ZXh0QWxpZ246ICdyaWdodCcsXG4gIGZvbnRTaXplOiAnMnJlbScsXG4gIG1hcmdpbkJvdHRvbTogdGhlbWUuc3BhY2luZygyKSxcbiAgbWluSGVpZ2h0OiAnNjRweCcsXG4gIGJhY2tncm91bmQ6ICcjZjVmNWY1JyxcbiAgd29yZEJyZWFrOiAnYnJlYWstYWxsJ1xufSkpO1xuXG5jb25zdCBDYWxjdWxhdG9yQ29tcG9uZW50ID0gKCkgPT4ge1xuICBjb25zdCBbZGlzcGxheSwgc2V0RGlzcGxheV0gPSB1c2VTdGF0ZSgnMCcpO1xuICBjb25zdCBbZmlyc3ROdW1iZXIsIHNldEZpcnN0TnVtYmVyXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbb3BlcmF0b3IsIHNldE9wZXJhdG9yXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbY2FsY3VsYXRvcl0gPSB1c2VTdGF0ZShuZXcgQ2FsY3VsYXRvcigpKTtcbiAgY29uc3QgW3dhaXRpbmdGb3JTZWNvbmROdW1iZXIsIHNldFdhaXRpbmdGb3JTZWNvbmROdW1iZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaGlzdG9yeSwgc2V0SGlzdG9yeV0gPSB1c2VTdGF0ZShbXSk7IFxuXG5cbiAgY29uc3QgYnV0dG9ucyA9IFtcbiAgICBbJzcnLCAnOCcsICc5JywgJysnXSxcbiAgICBbJzQnLCAnNScsICc2JywgJy0nXSxcbiAgICBbJzEnLCAnMicsICczJywgJyonXSxcbiAgICBbJ0MnLCAnMCcsICc9JywgJy8nXVxuICBdO1xuXG4gIGNvbnN0IGhhbmRsZU51bWJlciA9IChudW0pID0+IHtcbiAgICBpZiAod2FpdGluZ0ZvclNlY29uZE51bWJlcikge1xuICAgICAgc2V0RGlzcGxheShudW0pO1xuICAgICAgc2V0V2FpdGluZ0ZvclNlY29uZE51bWJlcihmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldERpc3BsYXkoZGlzcGxheSA9PT0gJzAnID8gbnVtIDogZGlzcGxheSArIG51bSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZU9wZXJhdG9yID0gKG9wKSA9PiB7XG4gICAgc2V0Rmlyc3ROdW1iZXIocGFyc2VGbG9hdChkaXNwbGF5KSk7XG4gICAgc2V0T3BlcmF0b3Iob3ApO1xuICAgIHNldFdhaXRpbmdGb3JTZWNvbmROdW1iZXIodHJ1ZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRXF1YWxzID0gKCkgPT4ge1xuICAgIGlmIChmaXJzdE51bWJlciA9PT0gbnVsbCB8fCBvcGVyYXRvciA9PT0gbnVsbCkgcmV0dXJuO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGNhbGN1bGF0b3IuY2FsY3VsYXRlKFxuICAgICAgICBmaXJzdE51bWJlcixcbiAgICAgICAgb3BlcmF0b3IsXG4gICAgICAgIHBhcnNlRmxvYXQoZGlzcGxheSlcbiAgICAgICk7XG4gICAgICBzZXREaXNwbGF5KHJlc3VsdC50b1N0cmluZygpKTtcbiAgICAgIHNldEZpcnN0TnVtYmVyKG51bGwpO1xuICAgICAgc2V0T3BlcmF0b3IobnVsbCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldERpc3BsYXkoJ0Vycm9yJyk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNsZWFyID0gKCkgPT4ge1xuICAgIHNldERpc3BsYXkoJzAnKTtcbiAgICBzZXRGaXJzdE51bWJlcihudWxsKTtcbiAgICBzZXRPcGVyYXRvcihudWxsKTtcbiAgICBzZXRXYWl0aW5nRm9yU2Vjb25kTnVtYmVyKGZhbHNlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDbGVhckhpc3RvcnkgPSAoKSA9PiB7XG4gICAgY2FsY3VsYXRvci5jbGVhckhpc3RvcnkoKTtcbiAgICBzZXRIaXN0b3J5KFtdKTsgLy8gTWV0dHJlIMOgIGpvdXIgbCfDqXRhdCBsb2NhbFxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUJ1dHRvbkNsaWNrID0gKHZhbHVlKSA9PiB7XG4gICAgc3dpdGNoICh2YWx1ZSkge1xuICAgICAgY2FzZSAnPSc6XG4gICAgICAgIGhhbmRsZUVxdWFscygpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ0MnOlxuICAgICAgICBoYW5kbGVDbGVhcigpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJysnOlxuICAgICAgY2FzZSAnLSc6XG4gICAgICBjYXNlICcqJzpcbiAgICAgIGNhc2UgJy8nOlxuICAgICAgICBoYW5kbGVPcGVyYXRvcih2YWx1ZSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaGFuZGxlTnVtYmVyKHZhbHVlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwic21cIj5cbiAgICAgIDxCb3ggc3g9e3sgbXQ6IDQgfX0+XG4gICAgICAgIDxEaXNwbGF5IGVsZXZhdGlvbj17M31cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cImRpc3BsYXlcIj5cbiAgICAgICAgICB7ZGlzcGxheX1cbiAgICAgICAgPC9EaXNwbGF5PlxuICAgICAgICA8R3JpZCBjb250YWluZXIgc3BhY2luZz17MX0+XG4gICAgICAgICAge2J1dHRvbnMubWFwKChyb3csIHJvd0luZGV4KSA9PiAoXG4gICAgICAgICAgICA8R3JpZCBjb250YWluZXIgaXRlbSBzcGFjaW5nPXsxfSBrZXk9e3Jvd0luZGV4fT5cbiAgICAgICAgICAgICAge3Jvdy5tYXAoKGJ1dHRvbikgPT4gKFxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezN9IGtleT17YnV0dG9ufT5cbiAgICAgICAgICAgICAgICAgIDxDYWxjQnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxuICAgICAgICAgICAgICAgICAgICBjb2xvcj17XG4gICAgICAgICAgICAgICAgICAgICAgYnV0dG9uID09PSAnPScgPyAncHJpbWFyeScgOlxuICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbiA9PT0gJ0MnID8gJ2Vycm9yJyA6XG4gICAgICAgICAgICAgICAgICAgICAgWycrJywgJy0nLCAnKicsICcvJ10uaW5jbHVkZXMoYnV0dG9uKSA/ICdzZWNvbmRhcnknIDpcbiAgICAgICAgICAgICAgICAgICAgICAnaW5mbydcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVCdXR0b25DbGljayhidXR0b24pfVxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD17YGJ1dHRvbi0ke2J1dHRvbn1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7YnV0dG9ufVxuICAgICAgICAgICAgICAgICAgPC9DYWxjQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvR3JpZD5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L0dyaWQ+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvR3JpZD5cbiAgICAgICAgXG4gICAgICAgIHsvKiBIaXN0b3JpcXVlICovfVxuICAgICAgICA8Qm94IHN4PXt7IG10OiA0IH19PlxuICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNlwiPkhpc3RvcmlxdWU8L1R5cG9ncmFwaHk+XG4gICAgICAgICAge2NhbGN1bGF0b3IuZ2V0SGlzdG9yeSgpLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgIDxQYXBlciBcbiAgICAgICAgICAgICAga2V5PXtpbmRleH0gXG4gICAgICAgICAgICAgIHN4PXt7IFxuICAgICAgICAgICAgICAgIHA6IDIsIFxuICAgICAgICAgICAgICAgIG15OiAxLCBcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsIFxuICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicgXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuPntpdGVtLmV4cHJlc3Npb259ID0ge2l0ZW0ucmVzdWx0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0udGltZXN0YW1wLnRvTG9jYWxlVGltZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvUGFwZXI+XG4gICAgICAgICAgKSl9XG4gICAgICAgICAge2NhbGN1bGF0b3IuZ2V0SGlzdG9yeSgpLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvbiBcbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCIgXG4gICAgICAgICAgICAgIGNvbG9yPVwiZXJyb3JcIiBcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJIaXN0b3J5fVxuICAgICAgICAgICAgICBzeD17eyBtdDogMiB9fVxuICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImNsZWFyLWhpc3RvcnlcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBFZmZhY2VyIGwmYXBvcztoaXN0b3JpcXVlXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L0JveD5cbiAgICAgIDwvQm94PlxuICAgIDwvQ29udGFpbmVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQ2FsY3VsYXRvckNvbXBvbmVudDtcbiJdLCJmaWxlIjoiL1VzZXJzL21vaGFtZWQvRG9jdW1lbnRzL0NhbGN1bGF0b3Ivc3JjL2NvbXBvbmVudHMvQ2FsY3VsYXRvci5qc3gifQ==