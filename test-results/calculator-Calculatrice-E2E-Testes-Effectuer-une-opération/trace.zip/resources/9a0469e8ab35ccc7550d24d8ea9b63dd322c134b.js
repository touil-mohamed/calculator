import {
  require_react
} from "/node_modules/.vite/deps/chunk-JSZTVBPD.js?v=e7b5a740";
export default require_react();
//# sourceMappingURL=react.js.map
